package com.choiseonyoung.spring

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class KSpring02Application

fun main(args: Array<String>) {
	runApplication<KSpring02Application>(*args)
}
