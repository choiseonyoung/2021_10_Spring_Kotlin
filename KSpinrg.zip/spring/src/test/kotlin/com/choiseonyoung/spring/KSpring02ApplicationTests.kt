package com.choiseonyoung.spring

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class KSpring02ApplicationTests {

	@Test
	fun contextLoads() {
	}

}
